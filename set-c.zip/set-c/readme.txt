Exercise 03: Set C: Write a ReactJS program that computes the GWA of a student and outputs the
remarks.

Submitted by: Glenn Mark Cruz
Submitted to: Mr. Carl Angelo Angcana