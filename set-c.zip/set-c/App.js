import { useState } from 'react';
import { View, Text,ScrollView,StyleSheet, TextInput, Button } from 'react-native';

const GwaCalculator = () => {
  const gradePoints = {
    1.00: 'Excellent',
    1.25: 'Superior',
    1.50: 'Very Good',
    1.75: 'Good',
    2.00: 'Very Satisfactory',
    2.25: 'High Average',
    2.50: 'Average',
    2.75: 'Fair',
    3.00: 'Pass',
    4.00: 'Conditional',
    5.00: 'Failure',
  };

  const [grades, setGrades] = useState([]);
  const [totalUnits, setTotalUnits] = useState(0);
  const [gwa, setGwa] = useState(0);
  const [Status, setStatus] = useState('');

  const handleInputChange = (index, key, value) => {
  const updatedGrades = [...grades];
  updatedGrades[index][key] = value;
  setGrades(updatedGrades);
};

  const handleCalculateGwa = () => {
    let totalGradeUnits = 0;
    let totalUnits = 0;

    grades.forEach((subject) => {
      const grade = parseFloat(subject.grade);
      const units = parseFloat(subject.units);

      if (!isNaN(grade) && !isNaN(units)) {
        totalGradeUnits += grade * units;
        totalUnits += units;
      }
    });

    const computedGwa = totalGradeUnits / totalUnits;
    const computedStatus = getStatus(computedGwa);

    setTotalUnits(totalUnits);
    setGwa(computedGwa);
    setStatus(computedStatus);
  };

  const getStatus = (computedGwa) => {
    for (const gradePoint in gradePoints) {
      if (computedGwa <= parseFloat(gradePoint)) {
        return gradePoints[gradePoint];
      }
    }

    return '';
  };

  const renderGradeInputs = () => {
  return grades.map((subject, index) => {
    return (
      <View key={index} style={styles.inputContainer}>
        <Text style={styles.label}>Enter Subject:</Text>
        <TextInput
          style={styles.inputField}
          placeholder='Subject'
          onChangeText={(value) =>
            handleInputChange(index, 'subject', value)
          }
          value={subject.subject}
        />
        <Text style={styles.label}>Enter Grade:</Text>
        <TextInput
          style={styles.inputField}
          placeholder='0.0'
          keyboardType='decimal-pad'
          onChangeText={(value) =>
            handleInputChange(index, 'grade', value)
          }
          value={subject.grade}
        />
        <Text style={styles.label}>Enter Units:</Text>
        <TextInput
          style={styles.inputField}
          placeholder='0'
          keyboardType='numeric'
          onChangeText={(value) =>
            handleInputChange(index, 'units', value)
          }
          value={subject.units}
        />
      </View>
    );
  });
};

  const handleAddSubject = () => {
    setGrades([...grades, { subject: '', grade: '', units: '' }]);
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
      <Text style={styles.title}>Set C: {'\n'}GWA Of A Student
</Text>
      {renderGradeInputs()}
      <Button title='Add Subject' onPress={handleAddSubject} />
      <Button title='Calculate GWA' onPress={handleCalculateGwa} />
      <View style={styles.results}>
        <Text style={styles.subtitle}>
          Total Units: {totalUnits}
          {'\n'}
          GWA: {gwa.toFixed(2)}
          {'\n'}
          Status: {Status}
        </Text>
      </View>
    </ScrollView>
</View>
);
};

const styles = StyleSheet.create({
  inputContainer: {
    alignItems: 'center',       
    marginBottom: 10,
    backgroundColor: '#7fffd4',
    padding: 10,
    borderRadius: 5,
  },
  
  label: {
    fontWeight: 'bold',
    marginBottom: 5,
  },

  inputField: {
    backgroundColor: '#a9a9a9',
    padding: 10,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#2f4f4f',
    marginBottom: 10,
  },

  title: {
  flexDirection: 'row',
  textAlign: 'center',
  fontSize: 24,
  fontWeight: 'bold',
  marginBottom: 20,
  marginTop: 80,
},
  results: {
  alignItems: 'center',
  backgroundColor: '#a9a9a9',
  marginTop: 10,
  borderWidth: 5,
  borderColor: 'dimgray',
  padding: 10,
  borderRadius: 5,
},
  subtitle: {
  fontSize: 20,
 },
});

export default GwaCalculator;
